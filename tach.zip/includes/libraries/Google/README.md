[![Build Status](https://travis-ci.org/google/google-api-php-client.svg)](https://travis-ci.org/google/google-api-php-client)

# Google APIs Client Library for PHP #

## Description ##
The Google API Client Library enables you to work with Google APIs such as Google+, Drive, or YouTube on your server.sdkjdjfskfsdfkjdsfdskjRatana A-sdjdlkfjsdflksd-787-dsdssdsd6-ratanasok