<?php
function run_pager($app) {
     TaskManager::run();
    return redirect_back();
}