<?php
function check_pager($app) {

    return pusher()->result();
}
 