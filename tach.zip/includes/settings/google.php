<?php
return array(
    'title' => 'Google Analytics Code',
    'description' => lang('google-analytics-code-desc'),
    'settings' => array(


        'google-analytics-code' => array(
            'title' => 'Google Analytics Code',
            'description' => lang('google-analytics-code-desc'),
            'type' => 'textarea',
            'value' => '',
        ),


    )
);
 