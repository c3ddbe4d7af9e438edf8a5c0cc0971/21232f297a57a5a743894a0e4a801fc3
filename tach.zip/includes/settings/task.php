<?php
return array(
    'title' => 'Task Scheduler',
    'description' => 'Control how background tasks are executed',
    'settings' => array(


        'tasks-run-key' => array(
            'title' => 'Run Access Key',
            'description' => 'Set your tasks run access key here',
            'type' => 'text',
            'value' => 'runaccesskey',
        ),


    )
);
 