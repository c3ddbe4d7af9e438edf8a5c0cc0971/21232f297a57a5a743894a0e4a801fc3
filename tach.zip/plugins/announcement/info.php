<?php
return array(
    'title' => 'Announcement Plugin',
    'description' => 'This plugin allow you to create announcement for your members',
    'author' => 'crea8socialPRO Team',
    'link' => 'http://www.crea8social.com',
    'version' => '1.0'
);
 