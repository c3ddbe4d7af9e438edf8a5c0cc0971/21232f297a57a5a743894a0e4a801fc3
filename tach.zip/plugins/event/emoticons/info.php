<?php
return array(
    'title' => 'Emoticons',
    'description' => 'This plugin give your members option to add emoticons to their posts,comment e.t.c',
    'author' => 'crea8socialPRO Team',
    'link' => 'http://www.crea8socialPRO.com',
    'version' => '1.0'
);
 