<?php
return array(
    'emoticons' => 'Emoticons',
    'add-emoticons' => 'Add Emoticons',
    'manage-emoticons' => 'Manage Emoticons',
    'emoticon' => 'Emoticon',
    'sticker' => 'Sticker',
    'stickers' => 'Stickers',
    'edit-emoticon' => 'Edit Emoticon',
    'save-emoticon' => 'Save Emoticon',
    'search-emoticons' => 'Search emoticons'
);