<?php
return array(
    'title' => 'Events',
    'description' => 'This plugin allow your members to create events on your network',
    'author' => 'crea8socialPRO Team',
    'link' => 'http://www.crea8social.com',
    'version' => '1.0'
);
 