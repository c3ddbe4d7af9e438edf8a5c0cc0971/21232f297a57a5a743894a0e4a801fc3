<?php
return array(
    'title' => 'Birthdays',
    'description' => 'Display upcoming birthdays',
    'settings' => array()
);