<?php
return array(
    'title' => 'Event Menu',
    'description' => 'Display event menu',
    'settings' => array()
);