<?php
return array(
    'title' => 'Event Profile Invite',
    'description' => 'Display invite box for event profile',
    'settings' => array()
);