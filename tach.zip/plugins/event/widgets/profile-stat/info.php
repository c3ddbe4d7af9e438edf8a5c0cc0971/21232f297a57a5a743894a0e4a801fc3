<?php
return array(
    'title' => 'Event Profile RSVP',
    'description' => 'Display event profile rsvp statistics',
    'settings' => array()
);