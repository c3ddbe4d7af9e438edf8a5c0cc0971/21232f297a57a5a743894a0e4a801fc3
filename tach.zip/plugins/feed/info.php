<?php
return array(
    'title' => 'Feeds',
    'description' => 'This plugin provide item feed activities like user feeds, page feeds e.t.c',
    'core' => true,
    'author' => 'crea8socialPRO Team',
    'link' => 'http://www.crea8social.com',
    'version' => '1.0'
);
 