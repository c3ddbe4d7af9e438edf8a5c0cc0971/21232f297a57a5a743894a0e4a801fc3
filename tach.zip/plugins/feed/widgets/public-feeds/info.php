<?php
return array(
    'title' => 'Public Feeds',
    'description' => 'Display list of public feeds',
    'settings' => array()
);