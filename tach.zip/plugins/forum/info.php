<?php
return array(
    'title' => lang('forum::forum'),
    'description' => lang('forum::forum-desc'),
    'author' => lang('forum::forum-plugin-author'),
    'link' => 'http://www.crea8social.com',
    'version' => '2.0'
);
