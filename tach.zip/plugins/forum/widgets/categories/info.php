<?php
return array(
    'title' => lang('forum::forum-categories'),
    'description' => lang('forum::category-menu-desc'),
);