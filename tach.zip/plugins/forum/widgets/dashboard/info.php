<?php
return array(
    'title' => lang('forum::forum-dashboard'),
    'description' => lang('forum::main-menu-desc'),
);