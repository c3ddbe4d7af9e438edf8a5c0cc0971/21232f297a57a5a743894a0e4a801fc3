<?php
return array(
    'title' => lang('forum::forum-menu'),
    'description' => lang('forum::main-menu-desc'),
);