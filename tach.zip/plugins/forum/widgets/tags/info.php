<?php
return array(
    'title' => lang('forum::forum-tags'),
    'description' => lang('forum::category-menu-desc'),
);