<?php
return array(
    'title' => lang('game::main-menu'),
    'description' => lang('game::main-menu-desc'),
);