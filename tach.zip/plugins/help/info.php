<?php
return array(
    'title' => 'Help System',
    'description' => 'This plugin allow admin to create helps',
    'author' => 'crea8socialPRO Team',
    'link' => 'http://www.crea8socialPRO.com',
    'version' => '1.0'
);
 