<?php
return array(
    'title' => 'Help System',
    'description' => '',
    'settings' => array(
        'help-introduction' => array(
            'title' => lang('help::help-introduction'),
            'description' => lang('help::help-introduction-desc'),
            'type' => 'textarea',
            'value' => ''

        ),



    )
);
 