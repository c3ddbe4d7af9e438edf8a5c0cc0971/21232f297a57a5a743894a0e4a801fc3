<?php
return array(
    'title' => 'Letter Avatar',
    'description' => 'This plugin auto create letter avatar for new created accounts',
    'author' => 'crea8social Team',
    'link' => 'http://www.crea8social.com',
    'version' => '1.0'
);
 