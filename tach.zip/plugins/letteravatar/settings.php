<?php
return array(
    'title' => 'Letter Avatar',
    'description' => '',
    'settings' => array(
        'letteravatar-type' => array(
            'type' => 'selection',
            'title' => "Letter Avatar Type",
            'description' => '',
            'value' => '0',
            'data' => array(
                '0' => 'First Letter',
                '2' => 'Two Letter',
                '1' => 'Gender (F/M)'
            )
        )
    )
);
 