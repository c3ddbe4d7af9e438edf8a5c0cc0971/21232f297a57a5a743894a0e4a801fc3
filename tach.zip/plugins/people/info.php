<?php
return array(
    'title' => lang('people::people'),
    'description' => lang('people::people-desc'),
    'author' => lang('people::people-plugin-author'),
    'link' => 'http://www.crea8social.com',
    'version' => '1.0'
);
