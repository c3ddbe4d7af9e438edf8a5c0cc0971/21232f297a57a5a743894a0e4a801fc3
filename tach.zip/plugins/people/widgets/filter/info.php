<?php
return array(
    'title' => lang('people::filter'),
    'description' => lang('people::filter-desc'),
    'settings' => array(

    )
);