<?php
return array(
    'title' => lang('photo::Photos'),
    'description' => 'This plugin allow your members to upload photos, create photo albums e.t.c',
    'author' => 'crea8socialPRO Team',
    'link' => 'http://www.crea8social.com',
    'version' => '1.0'
);
 