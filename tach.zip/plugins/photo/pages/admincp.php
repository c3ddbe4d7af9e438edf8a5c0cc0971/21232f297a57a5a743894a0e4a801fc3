<?php
get_menu("admin-menu", "cms")->setActive()->findMenu("photo-manager")->setActive();

function albums_pager($app) {

}

function lists_pager($app) {

}

