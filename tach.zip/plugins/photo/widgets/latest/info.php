<?php
return array(
    'title' => lang('photo::latest-photos'),
    'description' => lang('Description'),
    'settings' => array(
        'limit' => array(
            'title' => lang(''),
            'description' => lang(''),
            'type' => 'text',
            'value' => 6
        )
    )
);