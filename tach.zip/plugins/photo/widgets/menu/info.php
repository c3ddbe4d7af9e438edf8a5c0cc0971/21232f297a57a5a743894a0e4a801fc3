<?php
return array(
    'title' => 'Photos Directory Menu',
    'description' => 'List photo directory menus',
    'settings' => array()
);