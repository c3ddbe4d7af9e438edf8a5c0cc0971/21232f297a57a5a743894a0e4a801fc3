<?php
return array(
    'title' => 'Report',
    'description' => 'This plugin allow your members to report posts, profile e.t.c',
    'author' => 'crea8socialPRO Team',
    'link' => 'http://www.crea8social.com',
    'version' => '1.0'
);
 