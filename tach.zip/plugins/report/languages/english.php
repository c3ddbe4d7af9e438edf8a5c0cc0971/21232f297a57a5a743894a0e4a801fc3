<?php
return array(
    'report-reason' => 'Give reason for your report...',
    'report' => 'Report',
    'report-content' => 'Report Content',
    'report-success' => 'Thanks for reporting, we will look into it..',
    'reports' => 'Reports',
    'manage-reports' => 'Manage Reports',
    'delete-report' => 'Delete Report',
    'take-action' => 'Take Action'
);
 