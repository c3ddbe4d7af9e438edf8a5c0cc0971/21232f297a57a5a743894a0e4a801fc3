<?php
function report_pager($app) {
    add_report(input('val'));
}
 