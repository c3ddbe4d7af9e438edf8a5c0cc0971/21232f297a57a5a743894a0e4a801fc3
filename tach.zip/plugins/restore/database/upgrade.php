<?php
function restore_upgrade_database() {
    $db = db();


}