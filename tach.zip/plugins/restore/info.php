<?php
// This file returns an array of information about the plugin.
return array(
	'title' => 'Backup and Restore',
	'description' => 'A plugin that backup and restore files, folders and database of the entire sccipt',
	'author' => 'crea8socialPRO Team',
	'link' => 'http://www.crea8social.com',
	'version' => '1.0'
);